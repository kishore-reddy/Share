import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class Main {

  public static void main(String[] args) throws Exception {
    BeanFactory beanFactory = new XmlBeanFactory(new ClassPathResource("context.xml"));
    PropertyEditorTestBean testBean = (PropertyEditorTestBean) beanFactory.getBean("testBean");

    System.out.println(testBean.isMyToggle());
  }
}

class PropertyEditorTestBean {
  private boolean myToggle;

  public boolean isMyToggle() {
      return myToggle;
  }
  public void setMyToggle(boolean myToggle) {
      this.myToggle = myToggle;
  }
}